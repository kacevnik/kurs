<?php if (!defined('FW')) die('Forbidden');

require_once dirname( __FILE__ ) . '/includes/templates/init.php';
