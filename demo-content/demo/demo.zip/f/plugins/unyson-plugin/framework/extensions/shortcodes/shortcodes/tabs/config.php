<?php if ( ! defined( 'FW' ) ) {
	die( 'Forbidden' );
}

$cfg = array();

$cfg['page_builder'] = array(
	'title'       => __( 'Tabs', 'fw' ),
	'description' => __( 'Add some Tabs', 'fw' ),
	'tab'         => __( 'Content Elements', 'fw' ),
);